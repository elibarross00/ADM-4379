<html>
<head>

</head>
<body>

</body>
	<form action="loginhandler.php" method="POST">
		Username*: 
			<input type= "text" name="username" required/></br></br>

		Password*: 
			<input type="text" name="password" required/>
			<input type="submit" value="Login">
	</form>


</html>