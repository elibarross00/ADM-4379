<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews</title>
    <style>
        /* CSS styles for reviews */
        .review {
            border: 1px solid #ccc;
            margin-bottom: 20px;
            padding: 10px;
        }
        .name {
            font-weight: bold;
        }
        .rating {
            color: gold;
        }
    </style>
</head>
<body>
    <h1>Reviews</h1>
    <div id="reviews">
        <?php
        // Database connection parameters
        $hostname = 'localhost'; 
        $username = '';
        $password = '';
        $dbname = 'reviews';

        // Establish a connection to the database
        try {
            $pdo = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);
            // Set PDO to throw exceptions on errors
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
            exit();
        }

        // Query to fetch reviews from the "reviews" table
        $sql = "SELECT username, building_name, rating, comment FROM reviews";

        // Prepare and execute the query
        try {
            $stmt = $pdo->query($sql);

            // Check if there are any reviews
            if ($stmt->rowCount() > 0) {
                // Loop through the reviews and generate HTML markup
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    ?>
                    <div class="review">
                        <h3 class="name"><?=htmlspecialchars($row['username'], ENT_QUOTES | ENT_HTML5, 'UTF-8')?></h3>
                        <p>Building Name: <?=htmlspecialchars($row['building_name'], ENT_QUOTES | ENT_HTML5, 'UTF-8')?></p>
                        <div>
                            <span class="rating"><?=str_repeat('&#9733;', $row['rating'])?></span>
                        </div>
                        <p class="content"><?=htmlspecialchars($row['comment'], ENT_QUOTES | ENT_HTML5, 'UTF-8')?></p>
                    </div>
                    <?php
                }
            } else {
                echo "No reviews available.";
            }
        } catch (PDOException $e) {
            echo "Error fetching reviews: " . $e->getMessage();
        }
        ?>
    </div>

    <h2>Filter by Building Name</h2>
    <select id="building_select">
        <option value="">All</option>
        <option value="DMS">DMS</option>
        <option value="CRX">CRX</option>
        <option value="MRT">MRT</option>
        <option value="FTX">FTX</option>
        <option value="FSS">FSS</option>
    </select>

    <script>
        // JavaScript code to filter reviews based on building name
        document.getElementById('building_select').addEventListener('change', function() {
            var selectedBuilding = this.value;
            var reviews = document.querySelectorAll('.review');

            reviews.forEach(function(review) {
                var buildingNameElement = review.querySelector('.name');
                var buildingName = buildingNameElement.textContent.trim();

                if (selectedBuilding === '' || buildingName === selectedBuilding) {
                    review.style.display = 'block';
                } else {
                    review.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
