// connect to db

execute query to get  buildings
hyperlink buildings

pass build id as paraemeter

