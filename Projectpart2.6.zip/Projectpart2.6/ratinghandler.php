<?php
include("connection.php");

$conn = new mysqli($server_name, $username, $password, $db_name); // open connection to SQLite DB

if ($conn->connect_error){
    die("Could not connect: " . $conn->connect_error);
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $username=$_POST['username'];
    $bname=$_POST['building_name'];
    $rating=$_POST['rating'];
    $comment=$_POST['comments'];


    $sql = "SELECT * FROM users WHERE username = '$username';";
    $result = $conn->query($sql);
    if ($result->num_rows <= 0){
        header("Location: signuppage.php?error=no_user&username=" . $username);
        $conn->close();
        exit;
    }
    

    $sql = "INSERT INTO reviews(username, building_name, rating, comment)
    VALUES ('$username', '$bname', '$rating', '$comment');"; 

    $result = $conn->query($sql);

    $conn->close();

    header ("Location: RatingSystem.php?username=" . $username);

}




?>