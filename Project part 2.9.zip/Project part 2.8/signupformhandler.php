<?php
include("connection.php");

$conn = new mysqli($server_name, $username, $password, $db_name); // open connection to SQLite DB

if ($conn->connect_error){
    die("Could not connect: " . $conn->connect_error);
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $first=$_POST['fname'];
    $last=$_POST['lname'];
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $status=$_POST['status'];
    
    //$password = password_hash ($password, PASSWORD_BCRYPT);

    $sql = "INSERT INTO users(first_name, last_name, username, email, password, status)
    VALUES ('$first', '$last', '$username', '$email', '$password', '$status');"; 

    $result = $conn->query($sql);


    $id=$conn-> insert_id;

    $conn->close();

    header ("Location: homepage.html?username=$username");

}





?>