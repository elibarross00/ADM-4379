<html>
<head>

<link rel="stylesheet" type="text/css" href="css code.css">
</head>

<section class="header-signup">
		<nav>
            <div class="topnav">
                <a class="active" href="Homepage.html">HOME</a>
                <a href="Information.html">INFORMATION</a>
                <a href="reviewsearch.php">REVIEWS</a>
                <a href="RatingSystem.php">RATE THE SPACE</a>
                
            </div>

		</nav>

<body>

<div class ="info-box">
<div class ="signup-box">

<h2>Sign Up</h2>
<form action="signupformhandler.php" method="post">
	<table>
		
			<label>Name*: </label>
			<input type="text" name="fname" placeholder="First Name" required/>
		<br></br>
			<input type="lastname" name="lname" placeholder="Last Name" required/>
		
		
			<label>Username*: </label>
			<input type= "text" name="username" required/>
	
	
			<label>Email*: </label>
			<input type= "text" name="email" required/>
	
		
		
			<label>Password*: </label>
			<input type="text" name="password" required/>
		
		
			<label>Student Status: </label>
			
			Student <input type="radio" name="status" value="student" checked/> 

			Non-Student <input type="radio" name="status" value="nonstudent"/> 

		
		
			<label>Program of Study:</label> 
			<select> 
				<option>Faculty of Arts </option>
				<option>Faculty of Education </option>
				<option>Faculty of Engineering </option>
				<option>Faculty of Medecine </option>
				<option>Faculty of Health Sciences </option>
				<option>Faculty of Law </option>
				<option>Faculty of Science </option>
				<option>Faculty of Social Sciences </option>
				<option>Telfer School of Management </option>

			</select>
			
		
		<!-- <tr>
			<td colspan="2"><input type="checkbox" name="consent" value="consent"/> I accept the terms and conditions. </td>
		</tr> -->
		
			<input type="submit" value="Create account"/> 
			<br></br>
			<input type="reset"/></td>	

	</table>
	

</form>

<p> Already have an account? <a href = "loginpage.php">Log In Here</a></p>

</div>
</div>

</body>
</html>

<?php
	if(isset($_GET['error'])){
		if($_GET['error'] == 'no_user'){
			echo "<h2 style='color:rgb(255, 0, 0);text-align:center;'>ERROR: The username: " . $_GET['username'] . " is not registered. Please sign-up!";
		}
	}

?>