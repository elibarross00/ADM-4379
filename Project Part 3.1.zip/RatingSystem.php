<!DOCTYPE html>
<html lang="en">
<head>
    <title>Tell us about your experience!</title>
    <link rel="stylesheet" type="text/css" href="RatingS.css">
<!--insert CSS-->
</head>
<body>
        <nav>
            <div class="topnav">
                <a class="active" href="Homepage.html">HOME</a>
                <a href="Information.html">INFORMATION</a>
                <a href="reviewsearch.php">REVIEWS</a>
                <a href="RatingSystem.php">RATE THE SPACE</a>
                
            </div>
    <h2>Tell us about your experience!</h2>
    To leave a review, please <a href="signuppage.php"> sign up</a> or <a href="loginpage.php"> log in!</a>

    <form action="ratinghandler.php" method="post">
        <p><h4>Please enter the following information: </h4></p>
        Username*: 
        <input type="text" name="username" required/><br/>
        Choose building name: 
        <br/>
        <input type="radio" name="building_name" value="DMS" /> DMS: Demarais<br/>
        <input type="radio" name="building_name" value="CRX" /> CRX: Learning Crossroads<br/>
        <input type="radio" name="building_name" value="FSS" /> FSS: Faculty of Social Sciences<br/>
        <input type="radio" name="building_name" value="MRT" /> MRT: Morisset<br/>
        <input type="radio" name="building_name" value="FTX" /> FTX: Fauteux<br/>
        
        
        
        <h4>Rate your experience (1 star = not satisfied; 5 stars = very satisfied): </h4>
        <input type="radio" name="rating" value="1 star" /> 1 Star
        <input type="radio" name="rating" value="2 stars" /> 2 Stars
        <input type="radio" name="rating" value="3 stars" /> 3 Stars
        <input type="radio" name="rating" value="4 stars" /> 4 Stars
        <input type="radio" name="rating" value="5 stars" /> 5 Stars<br />
        
        <p><h4>Please share more about your experience: </h4></p>
        <textarea name="comments" cols="80" rows="5" placeholder="Describe your experience..."></textarea><br />
        
        <input type="submit" value="Submit" />
        <input type="reset" value="Reset" />
    </form>
</body>
</html>

<?php

if(isset($_GET['username'])){
    
        echo "<h2 style='color:rgb(0, 255, 0);text-align:center;'>SUCCESS:  " . $_GET['username'] . " has submitted a review!";
}

?>

