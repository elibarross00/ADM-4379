-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2024 at 06:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studyspaces_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `buildings`
--

CREATE TABLE `buildings` (
  `id` int(19) NOT NULL,
  `building_name` text NOT NULL,
  `quiet` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buildings`
--

INSERT INTO `buildings` (`id`, `building_name`, `quiet`) VALUES
(1, 'DMS', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(19) NOT NULL,
  `user_id` int(19) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `building_name` text NOT NULL,
  `rating` tinyint(5) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `submit_date` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `username`, `building_name`, `rating`, `comment`, `submit_date`) VALUES
(4, NULL, 'Deep', 'Minto', 3, 'satisfactory', '2024-03-14 20:04:38'),
(5, NULL, 'Yaqi', 'DMS', 4, 'good', '2024-03-14 21:52:25'),
(6, NULL, 'Bruna', 'DMS', 4, 'Beautiful', '2024-03-14 22:34:46'),
(7, NULL, 'Eli', 'DMS', 4, 'great', '2024-03-15 16:54:27'),
(8, NULL, 'Vivek', 'MRT', 3, 'It was OKay', '2024-03-18 23:31:45'),
(9, NULL, 'Deep', 'CRX', 5, 'Nice study spots.', '2024-03-19 00:20:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `username` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `status`) VALUES
(1, 'Deepshika', 'Jhundoo', 'Vivek', 'deepshikajhundoo@gmail.com', '123', 0),
(2, 'Deepshika', 'Jhundoo', 'Deep', 'deepshikajhundoo@gmail.com', '123', 0),
(3, 'Deepshika', 'Jhundoo', 'Yaqi', 'deepshikajhundoo@gmail.com', '$2y$10$StV', 0),
(4, 'Deepshika', 'Jhundoo', 'Bruna', 'deepshikajhundoo@gmail.com', '$2y$10$aZi', 0),
(5, 'Deepshika', 'Jhundoo', 'Eli', 'deepshikajhundoo@gmail.com', '$2y$10$reK', 0),
(6, 'Deepshika', 'Jhundoo', 'S', 'deepshikajhundoo@gmail.com', 'Q', 0),
(7, 'Cherri', 'Toupee', 'Venom', 'cherritoup@gmail.com', '123', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buildings`
--
ALTER TABLE `buildings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `building_name` (`building_name`(768)),
  ADD KEY `Quiet` (`quiet`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buildings`
--
ALTER TABLE `buildings`
  MODIFY `id` int(19) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(19) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `test` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
