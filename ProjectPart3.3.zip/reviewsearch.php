<!DOCTYPE html>
<html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Search Reviews</title>
<link rel="stylesheet" type="text/css" href="css code.css">
</head>                                                        <!--INSERT DESCRIPTION OF WHAT THIS PAGE DOES-->
<body>
<nav>
    <div class="topnav">
        <a href="Homepage.html">HOME</a>
        <a href="Information.html">INFORMATION</a>         
        <a class= "active" href="reviewsearch.php">REVIEWS</a>
        <a href="RatingSystem.php">RATE THE SPACE</a>
                
     </div>
</nav>


<form action="" method="get">
        <p><h2>Please choose a building to view its ratings: </h2></p>
        Building name: 
        <br />
        <input type="radio" name="building_name" value="DMS" /> DMS: Demarais<br />
        <input type="radio" name="building_name" value="CRX" /> CRX: Learning Crossroads<br />
        <input type="radio" name="building_name" value="FSS" /> FSS: Faculty of Social Sciences<br />
        <input type="radio" name="building_name" value="MRT" /> MRT: Morisset<br />
        <input type="radio" name="building_name" value="FTX" /> FTX: Fauteux<br />
        
        <input type="submit" value="Search" />
    </form>
</body>    
</html>

<?php
include("connection.php");

$conn = new mysqli($server_name, $username, $password, $db_name); // open connection to SQLite DB

if ($conn->connect_error){
    die("Could not connect: " . $conn->connect_error);
}

if (isset($_GET['building_name'])){
    //getting all reviews data from the record:
    $building_chosen = $_GET['building_name'];

    echo "<table>
    <tr>
      <td>";

    if ($building_chosen == 'DMS'){
        echo "<img style='width:500px;height=500px;' src='images/DMS_map.jpg' alt='Desmarais Hall'>
    </td>
    
    <td>
      <p><strong>Desmarais Hall (DMS):</strong> 55 Laurier Avenue East</p>
      <p>The Desmarais Building, a new flagship building for Canada’s university, is named after renowned Canadian and international businessman and alumnus of the University of Ottawa, Paul G. Desmarais.</p>
      <p><strong>Amenities:</strong> Student Lounge / Microwave / Printing machine</p>";

    } elseif ($building_chosen == 'CRX'){
        echo "<img style='width:500px;height=500px;' src='images/CRX_map.jpg' alt='CRX'>
        </td>
    
        <td>
          <p><strong>CRX:</strong> 100 Louis-Pasteur Private</p>
          <p>CRX are three letters that have been creating quite a buzz on campus recently. The Learning Crossroads, or CRX for short, is the new state-of-the-art building added to the east side of Lamoureux Hall, facing the Brooks Residences.</p>
          <p><strong>Amenities:</strong> Student area / Microwave / Study Room</p>";
    } elseif($building_chosen == 'MRT'){
        echo "<img style='width:500px;height=500px;' src='images/MRT_map.WEBP' alt='Morisset Hall'>
        </td>
        
        <td>
          <p><strong>Morisset Hall (MRT):</strong> 65 University Private</p>
          <p>Morisset Hall is a six-storey building plus two basements, which houses the social sciences and humanities library at Levels 1, 3, 4, 5 and 6 and the administration of the library and Multimedia Distribution Services at Levels 0 and 2. Level 00 houses campus radio, laboratories and studios operated by the Department of Communications, storages and mechanical rooms.</p>
          <p><strong>Amenities:</strong> Study room / Library / Printing machine</p>";
    } elseif($building_chosen == 'FTX'){
        echo "<img style='width:500px;height=500px;padding=100px;' src='images/FTX_map.PNG' alt='Fauteux Hall'>
        </td>
        
        <td>
          <p><strong>Fauteux Hall (FTX)</strong></p>
          <p>The Common Law Section’s faculty is composed of a wide range of experts, many of whom are renowned as leaders in their respective fields. Through their scholarship, many of our professors have contributed to the transformation of Canada’s legal systems as well as the ways in which law is practiced, taught and conceived.</p>
          <p><strong>Amenities:</strong> Student Lounge / Printing machine / Microwave</p>";
          
    } elseif ($building_chosen == 'FSS'){
        echo "<img style='width:500px;height=500px;' src='images/FSS_map.JPEG' alt='Faculty of Social Sciences'>
        </td>
        
        <td>
          <p><strong>Faculty of Social Sciences (FSS)</strong></p>
          <p>A vibrant community of 10,000 students and 270 professors is at the heart of the cutting-edge research and events that define the Faculty of Social Sciences. It’s renowned for interdisciplinary studies: its nine academic units offer a wide array of programs in French and in English</p>
          <p><strong>Amenities:</strong> Study area / Student Lounge / Study room</p>";
    }

    echo "</td>
    </tr>
  </table>";

    $sql = "SELECT * FROM reviews WHERE building_name = '$building_chosen' ORDER BY rating DESC";
    try{
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            echo "<table style='border-collapse: collapse; width: 100%;'>";
            echo "<tr style='border-bottom: 1px solid black;'>
                    <th style='padding: 10px; border-right: 1px solid black;'>
                        Reviewed by
                    </th>
                    <th style='padding: 10px; border-right: 1px solid black;'>
                        Rating
                    </th>
                    <th style='padding: 10px;'>
                        Comment
                    </th></tr>";
            while($row = $result->fetch_assoc()){
                echo "<tr style='border-bottom: 1px solid black;'>
                    <td style='padding: 10px; border-right: 1px solid black;'>".$row["username"]."</td>
                    <td style='padding: 10px; border-right: 1px solid black;'>".$row["rating"]."</td>
                    <td style='padding: 10px;'>".$row["comment"]."</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No results found.";
        }
    }catch(mysqli_sql_exception $e){
        echo $e->getMessage();
    }
}

  
$conn->close(); 


?>