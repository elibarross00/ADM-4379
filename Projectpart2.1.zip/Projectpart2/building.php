<html>
    <!--will be changed to Navigate page. buildings-> amenities-->
// connect to DB

get building id from url

construct query to search building id from db
display building det

show all reviews
insert review
</html>