<html>
<!-- not included in project-->
<!--form to add a new study space to the website-->
<head>
	
</head>

<body>

<form action= method ="post">
	Building Name*: 
	<input type="text" name="building_name" placeholder="Building Name" required/>
	<input type="lastname" name="lname" placeholder="Last Name" required/>
		
		
	Location Description*: 
		<textarea name="description" cols="3" rows="30"></textarea> 
		
		
	Amenities available:
        <input type="checkbox" name="amenities" value="vending_machine"/>   <!--insert all possible amenities: cafe, dining hall, printer etc and add checkbox for each-->
		
		
		<!-- <tr>
			<td colspan="2"><input type="checkbox" name="consent" value="consent"/> I accept the terms and conditions. </td>
		</tr> -->

		<input type="submit" value="Add study space"/>
			<input type="reset"/>
		
	
</form>

</body>
</html>





