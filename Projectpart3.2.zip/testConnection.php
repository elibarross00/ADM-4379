<?php
    include("connection.php");

    $conn = new mysqli($server_name, $username, $password, $db_name); // open connection to SQLite DB

    if ($conn->connect_error){
        die("Could not connect: " . $conn->connect_error);
    }

    echo "Connection Successful!!";
    echo "<br>";

    $sql = "SELECT * FROM Person";
    $result = $conn->query($sql);
    // Process all rows
    while($row = $result->fetch_assoc()) {
        echo $row['name']; // Print a single column data
        echo "<br>";
        //echo print_r($row);       // Print the entire row data
    }


    $conn->close();
?>