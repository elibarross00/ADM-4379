<?php
    $server_name = "localhost";
    $username = "root";
    $password = "";
    $db_name = "studyspaces_db";



?>