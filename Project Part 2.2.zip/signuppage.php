<html>
<head>
	<style>
		th {
			background-color: #BAE3FF;
		}
		tr, td {
			background-color: #D8EFFF;
		}
		table, th, td {
			border-collapse: collapse;

		} 
		th, td {
			padding: 5px;
		}
	</style>
</head>
<!--insert CSS. can change table styling-->

<body>

<form action="signupformhandler.php" method="post">
	<table>
		<tr>
			<th>Name*: </th>
			<td><input type="text" name="fname" placeholder="First Name" required/></td> 
			<td><input type="lastname" name="lname" placeholder="Last Name" required/></td>
		</tr>
		<tr>
			<th>Username*: </th>
			<td><input type= "text" name="username" required/></td>
		</tr>
		<tr>
			<th>Email*: </th>
			<td><input type= "text" name="email" required/></td>
		</tr>
		
		<tr>
			<th>Password*: </th>
			<td><input type="text" name="password" required/></td>
		</tr>

		<tr>
			<th>Student Status: </th>
			<td><input type="radio" name="status" value="student" checked/> Student
			<input type="radio" name="status" value="nonstudent"/> Non-Student</td>
		</tr>
		
		<tr>
			<th>Program of Study: </th>
		
			<td>
			<select> 
				<option>Faculty of Arts </option>
				<option>Faculty of Education </option>
				<option>Faculty of Engineering </option>
				<option>Faculty of Medecine </option>
				<option>Faculty of Health Sciences </option>
				<option>Faculty of Law </option>
				<option>Faculty of Science </option>
				<option>Faculty of Social Sciences </option>
				<option>Telfer School of Management </option>

			</select>
			</td>
		</tr>
		<!-- <tr>
			<td colspan="2"><input type="checkbox" name="consent" value="consent"/> I accept the terms and conditions. </td>
		</tr> -->
		<tr>	
			<td><input type="submit" value="Create account"/>
			<input type="reset"/></td>
		</tr>	

	</table>
	
</form>

</body>
</html>

<?php
	if(isset($_GET['error'])){
		if($_GET['error'] == 'no_user'){
			echo "<h2 style='color:rgb(255, 0, 0);text-align:center;'>ERROR: The username: " . $_GET['username'] . " is not registered. Please sign-up!";
		}
	}

?>