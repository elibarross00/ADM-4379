<html>
<head>
<link rel="stylesheet" type="text/css" href="css code.css">
</head>
<body>

</body>
<section class="header-login">
		<nav>
            <div class="topnav">
                <a href="Homepage.html">HOME</a>
                <a href="Information.html">INFORMATION</a>
                <a href="reviewsearch.php">REVIEWS</a>
                <a href="RatingSystem.php">RATE THE SPACE</a>
				<a class="log" href="loginpage.php">LOG IN!</a>
                
            </div>

		</nav>

		<div class ="info-box">
		<div class ="login-box">
			<h2>Login</h2>
	<form action="loginhandler.php" method="POST">

		<label>Username*:</label>
		<input type= "text" name="username" required/></br></br>

		<label>Password*:</label>
			<input type="text" name="password" required/>
			<input type="submit" value="Login">
	</form>

	<p>Don't have an account? <a href = "signuppage.php">Sign Up Here</a></p>

	</div>
	</div>





</section>

</html>