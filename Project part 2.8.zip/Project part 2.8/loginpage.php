<html>
<head>

</head>
<body>

</body>
		<nav>
            <div class="topnav">
                <a class="active" href="Homepage.html">HOME</a>
                <a href="Information.html">INFORMATION</a>
                <a href="reviewsearch.php">REVIEWS</a>
                <a href="RatingSystem.php">RATE THE SPACE</a>
                
            </div>
	<form action="loginhandler.php" method="POST">
		Username*: 
			<input type= "text" name="username" required/></br></br>

		Password*: 
			<input type="text" name="password" required/>
			<input type="submit" value="Login">
	</form>


</html>